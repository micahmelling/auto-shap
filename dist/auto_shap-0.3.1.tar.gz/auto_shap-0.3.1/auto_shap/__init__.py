__version__ = '0.3.1'

from .auto_shap import *
