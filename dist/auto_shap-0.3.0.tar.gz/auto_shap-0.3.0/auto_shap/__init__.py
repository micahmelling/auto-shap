__version__ = '0.3.0'

from .auto_shap import *
