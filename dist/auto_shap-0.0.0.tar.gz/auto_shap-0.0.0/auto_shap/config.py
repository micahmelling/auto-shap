LINEAR_MODEL_NAMES = [
    'logisticregression', 'linearregression', 'elasticnet', 'ridge', 'lasso',
]

TREE_MODEL_NAMES = [
    'randomforest', 'extratrees', 'decisiontree', 'boost', 'gbm'
]

AMBIGUOUS_REGRESSION_MODEL_NAMES = [
    'elasticnet', 'ridge', 'lasso',
]
